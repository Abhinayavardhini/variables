import React, { Component } from 'react'

function Marksmemo(props) {

let engmarks= Number(props.engmarks);
let telmarks=Number(props.telmarks);
let hindimarks=Number(props.hindimarks);
let matmarks=Number(props.matmarks);
let scimarks=Number(props.scimarks);
let socmarks=Number(props.socmarks);
let totalmarks= telmarks+hindimarks+engmarks+matmarks+scimarks+socmarks;

const passmarks=40;
  return (
    <div>
      <table>
        <caption><b>Marks Memo Of {props.name}</b></caption>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Subjects</th>
                <th>Max Marks</th>
                <th>Marks Obtained</th>
                <th>Result</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
        <tr>
                <td>1.</td>
                <td>English</td>
                <td>100</td>
                <td>{engmarks}</td>
                <td>{engmarks>=40?"pass":"fail"}</td>
                <td>Excellent</td>
            </tr>
            <tr>
                <td>2.</td>
                <td>Telugu</td>
                <td>100</td>
                <td>{telmarks}</td>
                <td>{telmarks>=40?"pass":"fail"}</td>
                <td>Excellent</td>
            </tr>
            <tr>
                <td>3.</td>
                <td>Hindi</td>
                <td>100</td>
                <td>{hindimarks}</td>
                <td>{hindimarks>=40?"pass":"fail"}</td>
                <td>Average</td>
            </tr>
            <tr>
                <td>4.</td>
                <td>Maths</td>
                <td>100</td>
                <td>{matmarks}</td>
                <td>{matmarks>=40?"pass":"fail"}</td>
                <td>Excellent</td>
            </tr>
            <tr>
                <td>5.</td>
                <td>Science</td>
                <td>100</td>
                <td>{scimarks}</td>
                <td>{scimarks>=40?"pass":"fail"}</td>
                <td>Excellent</td>
            </tr>
            <tr>
                <td>6.</td>
                <td>social</td>
                <td>100</td>
                <td>{socmarks}</td>
                <td>{socmarks>=40?"pass":"fail"}</td>
                <td>Poor</td>
            </tr>
        </tbody>
        <tfoot>
        <tr>
                <th></th>
                <th>TOTAL</th>
                <th>600</th>
                <th>{totalmarks}</th>
                <th>pass</th>
                <th>Good</th>
            </tr>
        </tfoot>
      </table>
    </div>
  )
}

export default Marksmemo
