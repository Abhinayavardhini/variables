import logo from './logo.svg';
import './App.css';
import Marksmemo from './components/Marksmemo';

function App() {
  return (
    <div className="App">
     <Marksmemo name="Kavya" engmarks="91" telmarks="82" hindimarks="25" matmarks="89" scimarks="64" socmarks="78"/>
     <Marksmemo name="Latha"engmarks="69" telmarks="40" hindimarks="36" matmarks="49" scimarks="82" socmarks="56"/>
     <Marksmemo name="Siri"engmarks="49" telmarks="73" hindimarks="84" matmarks="77" scimarks="82" socmarks="25"/>
    </div>
  );
}

export default App;
